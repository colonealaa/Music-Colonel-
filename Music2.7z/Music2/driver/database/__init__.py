""" database copyright """

# thanks to TheHamkerCat (https://github.com/TheHamkerCat) for his WilliamButcherBot database.
# implemented by levina-lab (https://github.com/levina-lab)
